import { Controller, Get, Query, UseGuards, Req,  } from '@nestjs/common';
import { StatsService } from './stats.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('stats')
export class StatsController {
  constructor(private readonly statsService: StatsService) {}

  @Get('dashboard')
  async getDashboardStats(@Query() filters: any) {
      console.log('Appel à /stats/dashboard avec filters :', filters);
    return this.statsService.getDashboardStats(filters);
  }
  

  @Get('global')
  async getGlobalStats() {
    return {
      inscriptionsParType: await this.statsService.countByRole(),
      annoncesParType: await this.statsService.countAnnonces(),
    };
  }

 @Get('dashboard/client')
  @UseGuards(JwtAuthGuard)
  getClientDashboard(@Req() req) {
    return this.statsService.getDashboardStats({ utilisateurId: req.user.id });
  }
}
