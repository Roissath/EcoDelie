import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  OneToMany,
  JoinColumn,
} from 'typeorm';
import { Entrepot } from '../entrepot/entrepot.entity';
import { Annonce } from '../annonce/annonce.entity';
import { Utilisateur } from '../utilisateur/utilisateur.entity';
import { Stokage } from '../stokage/stokage.entity';

@Entity()
export class Colis {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ nullable: true })
  photo?: string;

  @Column()
  descriptif: string;

  @Column()
  dimension: string;

  @Column({ type: 'float' })
  prix_livraison: number;

  @Column({ default: false })
  assurance: boolean;

  @Column()
  statut: string;

  // ✅ Relation vers Entrepot
  @ManyToOne(() => Entrepot, (entrepot) => entrepot.colis, { onDelete: 'SET NULL' })
  @JoinColumn({ name: 'entrepotId' })
  entrepot: Entrepot;

  // ✅ Relation vers Annonce
  @ManyToOne(() => Annonce, (annonce) => annonce.colis, { onDelete: 'SET NULL' })
  @JoinColumn({ name: 'annonceId' })
  annonce: Annonce;

  // ✅ Relation vers Livreur (utilisateur)
  @ManyToOne(() => Utilisateur, (livreur) => livreur.colisLivreur, { onDelete: 'SET NULL' })
  @JoinColumn({ name: 'livreurId' })
  livreur: Utilisateur;

  // ✅ Relation inverse : stokages
  @OneToMany(() => Stokage, (stokage) => stokage.colis)
  stokages: Stokage[];

  
}
