import { Module } from '@nestjs/common'
import { CommentaireProduitService } from './commentaire-produit.service'
import { CommentaireProduitController } from './commentaire-produit.controller'

@Module({
  controllers: [CommentaireProduitController],
  providers: [CommentaireProduitService,]
})
export class CommentaireProduitModule {}
