import { Injectable, NotFoundException } from '@nestjs/common'
import { PrismaService } from '../prisma/prisma.service'
import { CreateCommentaireDto } from './dto/create-commentaire.dto'

@Injectable()
export class CommentaireProduitService {
  constructor(private prisma: PrismaService) {}

  async create(data: CreateCommentaireDto) {
    return this.prisma.commentaireProduit.create({
      data,
      include: { utilisateur: true },
    })
  }

  async findByProduit(produitId: number) {
    return this.prisma.commentaireProduit.findMany({
      where: { produitId },
      include: { utilisateur: true },
      orderBy: { createdA
        
        
        t: 'desc' },
    })
  }

  async remove(id: number) {
    const com = await this.prisma.commentaireProduit.findUnique({ where: { id } })
    if (!com) throw new NotFoundException('Commentaire non trouvé')
    return this.prisma.commentaireProduit.delete({ where: { id } })
  }

  async update(id: number, data: Partial<CreateCommentaireDto>) {
    const com = await this.prisma.commentaireProduit.findUnique({ where: { id } })
    if (!com) throw new NotFoundException('Commentaire non trouvé')
  
    return this.prisma.commentaireProduit.update({
      where: { id },
      data,
    })
  }
  
}
