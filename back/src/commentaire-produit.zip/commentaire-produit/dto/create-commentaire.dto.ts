import { IsString, IsInt } from 'class-validator'

export class CreateCommentaireDto {
  @IsString()
  contenu: string

  @IsInt()
  utilisateurId: number

  @IsInt()
  produitId: number
}
