import { Controller, Post, Get, Body, Param, Delete } from '@nestjs/common'
import { CommentaireProduitService } from './commentaire-produit.service'
import { CreateCommentaireDto } from './dto/create-commentaire.dto'
import { Patch } from '@nestjs/common'

@Controller('commentaires')
export class CommentaireProduitController {
  constructor(private readonly service: CommentaireProduitService) {}

  @Post()
  create(@Body() dto: CreateCommentaireDto) {
    return this.service.create(dto)
  }

  @Get('produit/:produitId')
  getByProduit(@Param('produitId') produitId: string) {
    return this.service.findByProduit(Number(produitId))
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.service.remove(Number(id))
  }

  @Patch(':id')
update(@Param('id') id: string, @Body() dto: Partial<CreateCommentaireDto>) {
  return this.service.update(+id, dto)
}
}
