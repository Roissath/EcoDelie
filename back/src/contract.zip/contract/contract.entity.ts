import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    ManyToOne,
    OneToMany,
    JoinColumn
  } from 'typeorm';
  import { Utilisateur } from '../utilisateur/utilisateur.entity';
  import { InfoPrestataire } from '../info-prestataire/info-prestataire.entity';
  import { InfoCommercant } from '../info-commercant/info-commercant.entity';
  
  @Entity()
  export class Contract {
    @PrimaryGeneratedColumn({ name: 'Id_contact' })
    id: number;
  
    @Column()
    contact_pdf: string;
  
    @Column()
    type: string;
  
    @ManyToOne(() => Utilisateur, (u) => u.contrats, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'Id_utilisateur' })
    utilisateur: Utilisateur;
  
    @OneToMany(() => InfoPrestataire, (p) => p.contract)
    prestataires: InfoPrestataire[];
  
    @OneToMany(() => InfoCommercant, (c) => c.contract)
    commercants: InfoCommercant[];
  }
  