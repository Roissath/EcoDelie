import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateContractDto } from './dto/create-contract.dto';
import { UpdateContractDto } from './dto/update-contrat.dto';

@Injectable()
export class ContractService {
  constructor(private prisma: PrismaService) {}

  create(data: CreateContractDto) {
    return this.prisma.contract.create({ data });
  }

  findAll() {
    return this.prisma.contract.findMany({
      include: { utilisateur: true, prestataires: true, commercants: true },
    });
  }

  findOne(id: number) {
    return this.prisma.contract.findUnique({
      where: { id },
      include: { utilisateur: true, prestataires: true, commercants: true },
    });
  }

  update(id: number, data: UpdateContractDto) {
    return this.prisma.contract.update({ where: { id }, data });
  }

  async remove(id: number) {
    const contract = await this.prisma.contract.findUnique({ where: { id } });
    if (!contract) throw new NotFoundException('Contrat non trouvé');
    return this.prisma.contract.delete({ where: { id } });
  }
}
