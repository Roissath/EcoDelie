'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Toaster, toast } from 'react-hot-toast'
import {
  User, Mail, MapPin, Smartphone, Globe,
  ShieldCheck, Trash, Upload, FileText
} from 'lucide-react'

interface Utilisateur {
  id: number
  nom: string
  prenom: string
  email: string
  telephone: string
  adresse: string
  langue_utilise?: string
  type_abonnement?: string
  photo_profil?: string
  role?: string
}

export default function ProfilClientPage() {
  const [user, setUser] = useState<Utilisateur | null>(null)
  const [loading, setLoading] = useState(true)
  const [file, setFile] = useState<File | null>(null)
  const router = useRouter()

  useEffect(() => {
    fetch('http://localhost:3001/auth/me', {
      method: 'GET',
      credentials: 'include',
    })
      .then(res => {
        if (!res.ok) throw new Error(`Erreur ${res.status}`)
        return res.json()
      })
      .then(data => setUser(data))
      .catch(() => {
        toast.error("Redirection vers la connexion...")
        router.push('/login')
      })
      .finally(() => setLoading(false))
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!user) return
    const { name, value } = e.target
    setUser({ ...user, [name]: value })
  }

  const handleSave = async () => {
    if (!user) return

    const res = await fetch(`http://localhost:3001/utilisateurs/${user.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        telephone: user.telephone,
        adresse: user.adresse,
        langue_utilise: user.langue_utilise,
      }),
      credentials: 'include',
    })

    if (res.ok) toast.success('Profil mis à jour')
    else toast.error('Erreur lors de la mise à jour')
  }

  const handleUploadPhoto = async () => {
    if (!user || !file) return
    const formData = new FormData()
    formData.append('file', file)

    const res = await fetch(`http://localhost:3001/utilisateurs/${user.id}/photo`, {
      method: 'PATCH',
      body: formData,
      credentials: 'include',
    })

    if (res.ok) {
      toast.success('Photo mise à jour')
      const data = await res.json()
      setUser({ ...user, photo_profil: data.photo_profil })
    } else {
      toast.error('Erreur envoi photo')
    }
  }

  const handleDeleteAccount = async () => {
    if (!user || !confirm('Es-tu sûr de vouloir supprimer ton compte ?')) return
    const res = await fetch(`http://localhost:3001/utilisateurs/${user.id}`, {
      method: 'DELETE',
      credentials: 'include',
    })

    if (res.ok) {
      toast.success('Compte supprimé')
      setTimeout(() => router.push('/'), 1500)
    } else {
      toast.error('Erreur lors de la suppression')
    }
  }

  if (loading) return (
    <div className="text-center mt-20 text-gray-500">Chargement du profil...</div>
  )

  if (!user) return null

  return (
    <div className="bg-[#FAFAFA] min-h-screen px-6 py-10">
      <Toaster position="top-right" />
      <div className="max-w-5xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8 space-y-8 border border-gray-100">
          <h1 className="text-3xl font-extrabold text-[#0070C0] border-b pb-4">Mon espace personnel</h1>

          <div className="flex items-center gap-6">
            <img
              src={`http://localhost:3001${user.photo_profil || '/default-avatar.png'}`}
              alt="Photo de profil"
              className="w-20 h-20 rounded-full border object-cover"
            />
            <div>
              <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] || null)} />
              <button onClick={handleUploadPhoto} className="text-sm text-blue-600 hover:underline mt-1 flex items-center gap-1">
                <Upload size={16} /> Mettre à jour la photo
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            <InputField icon={<User />} label="Nom complet" value={`${user.prenom ?? ''} ${user.nom ?? ''}`} readOnly />
            <InputField icon={<Mail />} label="Email" value={user.email ?? ''} readOnly />
            <InputField icon={<Smartphone />} label="Téléphone" name="telephone" value={user.telephone || ''} onChange={handleChange} />
            <InputField icon={<MapPin />} label="Adresse" name="adresse" value={user.adresse || ''} onChange={handleChange} />
            <InputField icon={<Globe />} label="Langue utilisée" name="langue_utilise" value={user.langue_utilise || ''} onChange={handleChange} />
            <InputField icon={<ShieldCheck />} label="Abonnement" value={user.type_abonnement || 'Standard'} readOnly />
          </div>

          <button
            onClick={handleSave}
            className="bg-[#0070C0] text-white py-2 px-6 rounded-xl hover:bg-blue-800 transition mt-4"
          >
            Enregistrer les modifications
          </button>

          <div className="pt-10 border-t mt-10">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Mes documents</h2>
            <button
              onClick={() => router.push(`/dashboard/client/documents/${user.id}`)}
              className="flex items-center gap-2 text-blue-600 hover:underline"
            >
              <FileText size={18} /> Voir mes documents
            </button>
          </div>

          <div className="pt-10 border-t">
            <h2 className="text-xl font-bold text-red-600 mb-2">Zone de danger</h2>
            <p className="text-gray-600 text-sm mb-2">Supprimer définitivement mon compte utilisateur.</p>
            <button onClick={handleDeleteAccount} className="bg-red-600 text-white px-4 py-2 rounded-xl flex items-center gap-2">
              <Trash size={16} /> Supprimer mon compte
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

function InputField({ icon, label, value, name, onChange, readOnly = false }: {
  icon: React.ReactNode,
  label: string,
  value: string,
  name?: string,
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void,
  readOnly?: boolean
}) {
  return (
    <div className="flex items-start gap-3">
      <span className="text-[#0070C0] mt-1">{icon}</span>
      <div className="w-full">
        <p className="text-sm font-medium text-gray-600">{label}</p>
        <input
          readOnly={readOnly}
          name={name}
          value={value}
          onChange={onChange}
          className={`w-full border p-2 rounded-lg text-black ${readOnly ? 'bg-gray-100 cursor-not-allowed' : ''}`}
        />
      </div>
    </div>
  )
}
